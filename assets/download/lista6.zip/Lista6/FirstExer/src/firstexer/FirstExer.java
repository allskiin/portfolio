package firstexer;

import java.util.Scanner;

public class FirstExer {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Insira a String: ");
        String string = in.next();
        System.out.print("Insira a posição de inicio:  ");
        int inicio = in.nextInt();
        System.out.print("Insira a posição do fim:  ");
        int fim = in.nextInt();
        String sub = string.substring(inicio, fim);
        System.out.println("String: "+string +"\nSub: "+sub);
    }
    
}
