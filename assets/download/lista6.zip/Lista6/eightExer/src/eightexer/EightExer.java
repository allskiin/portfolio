/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eightexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class EightExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in = new Scanner(System.in);
        System.out.print("INSERE UMA STRING COM NÚMERO: ");
        String strNum = in.next();       
        int vetor[] = new int[strNum.length()];        
        for (int i = 0; i != strNum.length(); i++) 
            vetor[i]= Integer.valueOf(strNum.charAt(i));        
        for (int i = 0; i != strNum.length(); i++) 
            System.out.print(vetor[i]+" ");
    }
    
}
