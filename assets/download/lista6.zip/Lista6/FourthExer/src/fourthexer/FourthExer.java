/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package fourthexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class FourthExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("INSERE A STRING: ");
        String str = in.nextLine();
        String aux = str.substring(1);
        str = str.toUpperCase();
        String newE = str.substring(0, 1) + aux;
        System.out.println(newE);     
    }
    
}
