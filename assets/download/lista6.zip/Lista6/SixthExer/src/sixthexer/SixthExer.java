/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sixthexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class SixthExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in = new Scanner(System.in);
        System.out.print("INSERE A 1ª STRING: ");
        String str1 = in.next();
        System.out.print("INSERE A 2ª STRING: ");
        String str2 = in.next();        
        if(str2.length() == str1.length()){
            int aux = str2.length() -1;
            for (int i = 0; i != str1.length(); i++) {
                if(str1.charAt(i) != str2.charAt(aux)){
                    System.out.println("NÃO SÃO ANAGRAMA");
                    return;
                }
                aux--;
            }           
            System.out.println("SÃO ANAGRAMA");        
        }else
            System.out.println("NÃO SÃO ANAGRAMA");
    }
    
}
