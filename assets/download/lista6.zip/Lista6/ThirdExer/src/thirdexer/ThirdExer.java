package thirdexer;

import java.util.Arrays;
import java.util.Scanner;

public class ThirdExer {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("INSERE A STRING: ");
        String str = in.nextLine();
        String [] textoSeparado = str.split(" ");
        System.out.println(Arrays.toString(textoSeparado));
    }
    
}
