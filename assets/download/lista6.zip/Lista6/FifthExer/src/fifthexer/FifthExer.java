/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package fifthexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class FifthExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in = new Scanner(System.in);
        System.out.print("INSERE A STRING: ");
        String str = in.nextLine();
        System.out.println("Nova string "+str.replace(' ', '_'));
    }
    
}
