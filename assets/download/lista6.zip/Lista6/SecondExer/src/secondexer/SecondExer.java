/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package secondexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class SecondExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String string;
        int soma = 0;
        Scanner in = new Scanner(System.in);
        System.out.print("Insira a String: ");
        string = in.next();
            for (int i = 0; i < string.length(); i++)
                if(Character.isDigit(string.charAt(i)) == true)
                    soma += Character.getNumericValue(string.charAt(i));
        System.out.println("SOMA IGUAL: "+ soma); 
    }
    
}
