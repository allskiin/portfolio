#include <stdio.h>
#include <stdlib.h>

void InsertionShort(int *vetor, int tam){
    int i,j,aux, NumTrocas = 0, NumComparacoes = 0;
        for (i = 0; i < tam - 1; i++){
            NumComparacoes++;
            if(vetor[i] > vetor[i+1]){
                aux = vetor[i+1];
                vetor[i+1] = vetor[i];
                vetor[i] = aux;
                NumTrocas++;
                    j = i - 1;
                    while (j >= 0){
                        NumComparacoes++;
                        if(aux < vetor[j]){
                            vetor[j+1] = vetor[j];
                            vetor[j] = aux;
                            NumTrocas++;
                        }else   
                            break;
                        j -= 1;     
                    }   
            }
        }
        printf("\n-----------------------------"
            "\nCOMPARACOES: %d"
            "\nTROCAS: %d"
            "\n-----------------------------"
            , NumComparacoes, NumTrocas
        );
    
}

void BubbleShort(int *vetor, int tam){
    int i,j,aux = 0, NumTrocas = 0, NumComparacoes = 0;
    for (i = 0; i < tam; i++){
        for (j = 0; j < tam - 1; j++){
            NumComparacoes++;
            if(vetor[j] > vetor[j+1]){
                aux = vetor[j];
                vetor[j] = vetor[j+1];
                vetor[j+1] = aux;
                NumTrocas++;
            }
        }
    }
    printf("\n-----------------------------"
            "\nCOMPARACOES: %d"
            "\nTROCAS: %d"
            "\n-----------------------------"
            , NumComparacoes, NumTrocas
        );
}



int main(int argc, char const *argv[])
{
    int vetor[] = {4,5,8,2,9,1,3,7,6}, tam = 9, i;
    printf("\n########################\n-> INSERTION SHORT\n########################");
    printf("\n\nVETOR ORIGINAL: ");
        for(i = 0; i < tam; i++){
            printf("%d ", vetor[i]);
        }
    InsertionShort(vetor, tam);
    printf("\nVETOR ORDENADO: ");
        for(i = 0; i < tam; i++){
            printf("%d ", vetor[i]);
        }

    int vetor1[] = {4,5,8,2,9,1,3,7,6};
    printf("\n\n\n########################\n-> BUBBLE SHORT\n########################");
    printf("\n\nVETOR ORIGINAL: ");
        for(i = 0; i < tam; i++){
            printf("%d ", vetor1[i]);
        }
    BubbleShort(vetor1, tam);
    printf("\nVETOR ORDENADO: ");
        for(i = 0; i < tam; i++){
            printf("%d ", vetor1[i]);
        }    
    printf("\n\n\n");
    return 0;
}
