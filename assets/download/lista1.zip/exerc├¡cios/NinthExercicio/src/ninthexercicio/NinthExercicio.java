/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ninthexercicio;

import java.util.Scanner;

/**
 *
 * @author alyson
 */
public class NinthExercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num[] = new int[3],i,j,aux, op;
        for(i=0; i<3;i++){
            System.out.print("Digite o "+ i +"º número: ");
            num[i] = input.nextInt();
        }
        for(i=0; i<3;i++){
            for(j=i; j<3;j++){
                if(num[i] > num[j]){
                    aux = num[i];
                    num[i] = num[j];
                    num[j] = aux;
                }
            }
        }
        System.out.println("1 - Maior número");
        System.out.println("2 - Menor número");
        System.out.println("3 - Soma do quadrado dos números");
        System.out.println("4 - Multiplicação dos maiores");
        System.out.println("5 - Ordem descrecente");
        op = input.nextInt();
        switch (op) {
            case 1:
                System.out.println("Maior: "+ num[2]);
                break;
            case 2:
                System.out.println("Menor: "+ num[0]);
                break;
            case 3:
                
                System.out.println("Quadrado dos números: "+ (Math.pow(num[0], 2) + Math.pow(num[1], 2) + Math.pow(num[2], 2)));
                break;
            case 4:
                System.out.println("Multiplicação dos maiores: "+ (num[2]*num[1]));
                break;
            case 5:
                System.out.println("Ordem descrecente: "+ num[2]);
                System.out.println(num[1]);
                System.out.println(num[0]);
                break;
            default:
                System.out.println("Opção invalida.. ");
                break;
        }
    }
    
}
