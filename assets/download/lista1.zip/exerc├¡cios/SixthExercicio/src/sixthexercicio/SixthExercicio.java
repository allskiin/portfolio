/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sixthexercicio;

import java.util.Scanner;

/**
 *
 * @author alyson
 */
public class SixthExercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n1,n2,n3;
        System.out.print("Digite os números: ");
        n1 = input.nextInt(); 
        n2 = input.nextInt();
        n3 = input.nextInt();
        if(n1 == n2 && n1 == n3){
            System.out.println("Os números são iguais");
        }else{
            System.out.println("Os números não são iguais");
        }
    }
    
}
