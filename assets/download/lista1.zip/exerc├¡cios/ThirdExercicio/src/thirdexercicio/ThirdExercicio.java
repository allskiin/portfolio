/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package thirdexercicio;

/**
 *
 * @author alyson
 */

import java.util.Scanner;
public class ThirdExercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        float hp,lp,ha,la;
        int res;
        //entrada dos dados em centimetros
        System.out.print("Digite a altura da parede: ");
        hp = input.nextFloat();
        System.out.print("Digite a largura da parede: ");
        lp = input.nextFloat(); 
            //verificacao caso as medidas dos azuleijos forem maiores
            do{
                System.out.print("Digite a altura do azuleijo: ");
                ha = input.nextFloat();
            }while(ha > hp);
            do{
                System.out.print("Digite a largura do azuleijo: ");
                la = input.nextFloat();
            }while(la > lp);
        //calculos
        res = (int) ((hp / ha) * (lp / la));
        //resultado
        System.out.println("Serão necessários: "+ res + " azuleijos");
        
    }
    
}
