/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eighthexercicio;

import java.util.Scanner;

/**
 *
 * @author alyson
 */
public class EighthExercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        char letra;
        letra = input.next().charAt(0);
        if(letra == 'a' || letra == 'e' || letra == 'i' || letra == 'o' || letra == 'u')
            System.out.println("Letra "+ letra +" é vogal");
        else
            System.out.println("Letra "+ letra +" é consoante");
    }
    
}
