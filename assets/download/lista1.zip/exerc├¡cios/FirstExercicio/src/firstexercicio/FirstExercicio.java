/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package firstexercicio;

/**
 *
 * @author alyson
 */
import java.lang.Math;
import java.util.Scanner;

public class FirstExercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        int x1, y1, x2, y2;
        double res1, res2, resTotal;
        //leitura dos valores
        System.out.print("x1: ");
        x1 = entrada.nextInt();
        System.out.print("x2: ");
        x2 = entrada.nextInt();
        System.out.print("y1: ");
        y1 = entrada.nextInt();
        System.out.print("y2: ");
        y2 = entrada.nextInt();
        
        //operacoes
        res1  = Math.pow((x1+x2), 2);
        res2  = Math.pow((y1+y2), 2);
        resTotal = Math.sqrt(res1 + res2);
        
        //resultado
        System.out.println("ResTotal = " + resTotal);
    }
    
}
