/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package seventyexercicio;

import java.util.Scanner;

/**
 *
 * @author alyson
 */
public class SeventyExercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int h1,h2,m1,m2;
        h1 = input.nextInt();
        h2 = input.nextInt();
        m1 = input.nextInt();
        m2 = input.nextInt();
        if(h1 > h2){
            if(m1 > m2){
                System.out.println("Soma1 = "+ h1 + m2);
                System.out.println("Soma2 = "+ h2 * m1);
            }else{
                System.out.println("Soma1 = "+ h1 + m1);
                System.out.println("Soma2 = "+ h2 * m2);
            }
        }else{
            if(m1 > m2){
                System.out.println("Soma1 = "+ h2 + m2);
                System.out.println("Soma2 = "+ h1 * m1);
            }else{
                System.out.println("Soma1 = "+ h2 + m1);
                System.out.println("Soma2 = "+ h1 * m2);
            }
        }
    }
    
}
