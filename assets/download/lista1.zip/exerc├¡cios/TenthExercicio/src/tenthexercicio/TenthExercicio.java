/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tenthexercicio;

import java.util.Scanner;

/**
 *
 * @author alyson
 */
public class TenthExercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double preco,desconto;
        int op;
        System.out.print("Digite o preço normal de etiqueta: ");
        preco = input.nextDouble();
        System.out.println("Método de pagamento");
        System.out.println("1 - Dinheiro ou cheque");
        System.out.println("2 - Cartão de crédito");
        System.out.println("3 - Em duas vezes");
        System.out.println("4 - Em três vezes");
        op = input.nextInt();
        switch (op) {
            case 1:
                desconto = (preco*10)/100;
                System.out.println("A pagar: "+ (preco - desconto));
                break;
            case 2:
                desconto = (preco*5)/100;
                System.out.println("A pagar: "+ (preco - desconto));
                break;
            case 3:
                System.out.println("A pagar: "+ preco);
                break;
            case 4:
                desconto = (preco*10)/100;
                System.out.println("A pagar: "+ (preco + desconto));
                break;
            default:
                System.out.println("Opção invalida.. ");
                break;
        }
        
    }
    
}
