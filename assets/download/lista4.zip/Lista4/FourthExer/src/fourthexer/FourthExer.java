/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package fourthexer;


/**
 *
 * @author alyso
 */
public class FourthExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int res = 0, num = 1000;
        do{
            num++;
            if(num % 11 == 5)
                res++;
        }while(res != 5);
        System.out.println("O 5º maior número de 1000 cuja o resto da divisão por 11 é 5 é: "+ num);
    } 
}
