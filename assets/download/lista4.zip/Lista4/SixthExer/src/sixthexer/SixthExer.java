/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sixthexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class SixthExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int j, qnt, N;
        Scanner input = new Scanner(System.in);
        System.out.print("Insere o valor de N: "); N = input.nextInt();
            for(int i = 1; i<= N; i++){
                j = (i+3);
                qnt=0;
                System.out.print(i);
                System.out.print(",");
                    while(qnt < 2){
                        if(i < N){
                            System.out.print(j);
                            System.out.print(",");
                        }
                        qnt++; N--;
                    }
            }
    }
    
}
