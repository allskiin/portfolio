/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package secondexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class SecondExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int idade, qnt80=0; double peso, media80=0;
            for(int i = 1; i <= 22; i++){
                System.out.print("Insere a idade do : "+i+"º atleta: "); idade = input.nextInt();
                System.out.print("Insere o peso do : "+i+"º atleta: "); peso = input.nextDouble();
                    if(peso > 80){
                        qnt80++;
                        media80 += idade;
                    }
            }
            media80 /= qnt80;
            System.out.println("A quantidade de atletas com mais de 80 kilos é de: "+ qnt80);
            System.out.println("A média de atletas com mais de 80 kilos é de: "+ media80);
    }
    
}
