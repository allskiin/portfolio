/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tenthexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class TenthExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Número de motoristas: "); int totalM = input.nextInt();
        int maiorD = 0,numM = 0,totalD = 0;
        for (int i = 0; i < totalM; i++) {
            System.out.print("Digite o número da carta do "+(i+1)+"º motorista: "); int numC = input.nextInt();
            System.out.print("Digite o número de multas do "+(i+1)+"º motorista: "); int numMt = input.nextInt();
            int totalD_M = 0;
            for (int j = 0; j < numMt; j++) {
                System.out.print("Digite o valor da "+(j+1)+"ª multa: "); int valor = input.nextInt();
                totalD_M += valor;
            }
            System.out.println("Total da divida do motorista de carta número '"+numC+"' é: "+totalD_M);
            if(totalD_M > maiorD){
                maiorD = totalD_M;
                numM = numC;
            }
            totalD += totalD_M;     
        }
        System.out.println("O total de fundos arrecadados é de: "+totalD);
        System.out.println("O motorista com maior divida possui a carta número: "+numM);
    }
}
