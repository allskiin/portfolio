/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package thirdexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class ThirdExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int v1=0,v2=0,v3=0, vNulos=0, vBranco=0, op, total;
        do{
            System.out.print("Números dos Candidatos: \n-> 1\n-> 2\n-> 3\n-> 4 (Voto Nulo)\n-> 5 (Voto em branco)\n\nres:");
            op = input.nextInt();
                switch(op){
                    case 1: v1++; break; case 2: v2++; break; case 3: v3++; break; case 4: vNulos++; break; case 5: vBranco++; break; default: System.out.println("Opcao invalida..."); break;
                }
        }while(op != 0);      
            total = (v1+v2+v3+vNulos+vBranco);
        System.out.println("1º Candidato: "+v1);  
        System.out.println("2º Candidato: "+v2);  
        System.out.println("3º Candidato: "+v3);
        System.out.println("Votos Nulos: "+vNulos);
        System.out.println("Votos em Branco: "+vBranco);  
        System.out.println("Total: "+total);  
    }
    
}
