/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package firstexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class FirstExer {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num, res;
        for (int i = 0; i < 10; i++){
            System.out.print("Insere o número: "); num = input.nextInt();
            res = primo(num);
                if(res == 2)
                    System.out.println("O número "+ num +" é primo...");
                else
                    System.out.println("O número "+ num +" não é primo...");
        }
    }
    static int primo(int x){
        int primo = 0;
            for(int i = 1; i <= x; i++){
                if(x % i == 0)
                    primo++;
            }
        return primo;
    }
    
}
