/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ninthexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class NinthExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Digite o número: "); int num = input.nextInt();
        int res = 0, aux = num;
            while(aux > 0){
                int factorial = 1;
                for (int i = (aux % 10); i != 0; i--)
                    factorial *= i; 
                res += factorial;
                aux /= 10;
            }
        if(res == num)
            System.out.println("O número " + num +" é forte");
        else
            System.out.println("O número " + num +" não é forte");
    }
    
}
