/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eighthexer;

/**
 *
 * @author alyso
 */
public class EighthExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double grao = 1, total = 0;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                grao *= 2;
                total += grao;
            } 
        }
        System.out.println("O valor a pagar é de: "+total);
    }
    
}
