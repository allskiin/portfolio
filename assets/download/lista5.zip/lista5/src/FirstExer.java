import java.util.Scanner;

public class FirstExer {
    public static void main(String[] args) {
        try (Scanner input = new Scanner(System.in)) {
            float vet[] = new float[20];
            for (int i = 0; i < 20; i++) {
                if (i <= 9) {
                    System.out.print("Digite o " + (i + 1) + "º elemento do vetor: ");
                    vet[i] = input.nextFloat();
                } else if (i > 9) {
                    for (int j = 9; j >= 0; j--) {
                        vet[i] = vet[j];
                        i++;
                    }
                }
            }
        }
    }

}
