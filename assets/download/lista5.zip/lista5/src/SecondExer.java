import java.util.Scanner;

public class SecondExer {
    public static void main(String[] args) {
        try (Scanner input = new Scanner(System.in)) {
            int matriz[][] = new int[5][3];
            for (int i = 0; i < 5; i++) {
                for (int j = 0; j < 3; j++) {
                    System.out.print("Digite a altura do " + (j + 1) + "º atleta da " + (i + 1) + "ª equipa: ");
                    matriz[i][j] = input.nextInt();
                }
            }
            ordenar(matriz);
            System.out.print("\nMaior altura da 1ª equipa é: " + matriz[0][2]);
            System.out.print("\nMaior altura da 2ª equipa é: " + matriz[1][2]);
            System.out.print("\nMaior altura da 3ª equipa é: " + matriz[2][2]);
            System.out.print("\nMaior altura da 4ª equipa é: " + matriz[3][2]);
            System.out.print("\nMaior altura da 5ª equipa é: " + matriz[4][2] + "\n");
        }
    }

    static void ordenar(int matriz[][]) {
        int aux;
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 2; j++) {
                if (matriz[i][j] > matriz[i][j + 1]) {
                    aux = matriz[i][j];
                    matriz[i][j + 1] = matriz[i][j];
                    matriz[i][j] = aux;
                }
            }
        }
    }
}
