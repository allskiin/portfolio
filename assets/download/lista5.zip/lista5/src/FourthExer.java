import java.util.Scanner;

public class FourthExer {
    public static void main(String[] args) {
        try (Scanner input = new Scanner(System.in)) {
            System.out.print("Digite o valor: ");
            int n = input.nextInt();
            int mat[][] = new int[n][n];

            lerMatriz(n, mat);
            mostraMatriz(n, mat);

            int somaDP, somaDS;
            somaDP = somaDiagonalPrincipal(n, mat); // soma da diagonal principal
            somaDS = somaDiagonalSecundaria(n, mat); // soma da diagonal secundaria

            // soma linhas
            int vetL[] = new int[n];
            somaLinhas(n, mat, vetL);
            System.out.print("\nSoma das linhas: ");
            mostraVetor(vetL, n);

            // soma colunas
            int vetC[] = new int[n];
            somaColunas(n, mat, vetC);
            System.out.print("\nSoma das colunas: ");
            mostraVetor(vetC, n);

            System.out.println("\nSoma diagonal principal: " + somaDP + "\nSoma diagonal secundária: " + somaDS + "\n");

            boolean testaL = testaIgualidadeVetor(vetL, n);
            boolean testaC = testaIgualidadeVetor(vetC, n);

            if (testaC && testaL && somaDP == somaDS && somaDP == vetL[0])
                System.out.println("Resultado: Quadrado magico\n");
            else
                System.out.println("Resultado: Quadrado não magico\n");
        }

    }

    static void lerMatriz(int tam, int mat[][]) {
        try (Scanner input = new Scanner(System.in)) {
            for (int i = 0; i < tam; i++) {
                for (int j = 0; j < tam; j++) {
                    System.out.print("Digite o " + (j + 1) + "º elemento da " + (i + 1) + "ª linha: ");
                    mat[i][j] = input.nextInt();
                }
            }
        }
    }

    static void mostraMatriz(int tam, int mat[][]) {
        System.out.println("\nMatriz: ");
        for (int i = 0; i < tam; i++) {
            for (int j = 0; j < tam; j++)
                System.out.print(mat[i][j] + " ");
            System.out.print("\n");
        }
    }

    static int somaDiagonalPrincipal(int tam, int mat[][]) {
        int soma = 0;
        for (int i = 0; i < tam; i++)
            soma += mat[i][i];
        return soma;
    }

    static int somaDiagonalSecundaria(int tam, int mat[][]) {
        int soma = 0;
        for (int i = 0; i < tam; i++)
            soma += mat[i][tam - i - 1];
        return soma;
    }

    static void mostraVetor(int vet[], int tam) {
        for (int i = 0; i < tam; i++)
            System.out.print(vet[i] + " ");
    }

    static void somaLinhas(int tam, int mat[][], int vet[]) {
        for (int i = 0; i < tam; i++) {
            vet[i] = 0;
            for (int j = 0; j < tam; j++)
                vet[i] += mat[i][j];
        }
    }

    static void somaColunas(int tam, int mat[][], int vet[]) {
        for (int j = 0; j < tam; j++) {
            vet[j] = 0;
            for (int i = 0; i < tam; i++)
                vet[j] += mat[i][j];
        }
    }

    static boolean testaIgualidadeVetor(int vet[], int tam) {
        for (int i = 1; i < tam; i++) {
            if (vet[i] != vet[i - 1])
                return false;
        }
        return true;
    }
}
