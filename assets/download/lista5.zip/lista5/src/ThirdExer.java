import java.util.Scanner;

public class ThirdExer {
    public static void main(String[] args) {
        try (Scanner input = new Scanner(System.in)) {
            float matriz[][] = new float[5][5];
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    System.out.print("Digite o " + (j + 1) + "º número da " + (i + 1) + "ª linha: ");
                    matriz[i][j] = input.nextInt();
                }
            }
            System.out.print(
                    "\nSoma da 1ª coluna: "
                            + (matriz[0][0] + matriz[1][0] + matriz[2][0] + matriz[3][0] + matriz[4][0]));
            System.out.print("\nMultiplicação da 3ª linha: "
                    + (matriz[2][0] * matriz[2][1] * matriz[2][2] * matriz[2][3] * matriz[2][4]));
            System.out.print("\nSoma da diagonal principal: "
                    + (matriz[0][0] + matriz[1][1] + matriz[2][2] + matriz[3][3] + matriz[4][4]));
        }
    }
}
