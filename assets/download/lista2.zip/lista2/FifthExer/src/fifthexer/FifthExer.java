/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package fifthexer;

/**
 *
 * @author alyson
 */

import java.util.Scanner;
public class FifthExer {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double n1, n2, no, media;
        int op;
        n1 = input.nextDouble();
        n2 = input.nextDouble();
        no = 0;
        System.out.println("Deseja adicionar a nota opcinal? < sim - 1 & nao - 2 >"); op = input.nextInt();
            switch(op){
                case 1: 
                    no = input.nextDouble();
                    if(n1 > n2)
                       n2 = no;
                    else
                       n1 = no;
                        
                    break;
                case 2: 
                    no = -1;
                    
                    break;
            }
            media = (n1+n2)/2;
            System.out.println("Nota 1: "+ n1);
            System.out.println("Nota 2: "+ n2);
            System.out.println("Nota opcional: "+ no);
            System.out.println("A media é: "+ media);
            
            String res = (media >= 9.6)? "Aprovado": "Reprovado";
            System.out.println("RESULTADO: "+ res);              
    }
    
}
