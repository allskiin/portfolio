/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eightyexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class EightyExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("1- Tao Tui\n2- Mini Band e os Amigos\n3- Kalê\n4- Raio de Luz\nOpcao: ");
        int show = input.nextInt();
        switch (show) {
            case 1:
                System.out.println("Show: Tao Tui\nPreco: 15.000kz\nData: 03/04/2023 21:00");
                break;
            case 2:
                System.out.println("Show: Mini Band e os Amigos\nPreco: 3.500kz\nData: 04/04/2023 17:00");
                break;
            case 3:
                System.out.println("Show: Kalê\nPreco: 5.000kz\nData: 12/04/2023 18:00");
                break;
            case 4:
                System.out.println("Show: Raio de Luz\nPreco: 12.000kz\nData: 14/04/2023 18:00");
                break;
            default:
                System.out.println("Show invalido...");
                break;
        }
        
    }
    
}
