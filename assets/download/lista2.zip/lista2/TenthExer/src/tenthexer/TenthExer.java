/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tenthexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class TenthExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int dia=0, mes, ano, bis;
        do{
            System.out.print("Insere o mes: ");
            mes = input.nextInt();
        }while(mes <= 0 || mes > 12);
        do{
            System.out.print("Insere o ano: ");
            ano = input.nextInt();
            if(ano > 1999)
                ano = 0;
        }while(ano < 1000);
            if(ano % 400 == 0 || ano % 4 == 0)
                bis = 1;
            else
                bis = 2;
            
        if(bis == 1){
            switch (mes) {
                case 1:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 31)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 2:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 29)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 3:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 31)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 4:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 30)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 5:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                    }while(dia <= 0 && dia > 31);
                    break;
                case 6:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 30)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 7:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 31)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 8:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 31)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 9:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 30)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 10:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 31)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 11:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 30)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 12:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 31)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                default:
                    break;
            }
        }else if(bis == 2){
            System.out.println("O ano é bissesto");
            switch (mes) {
                case 1:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 31)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 2:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 28)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 3:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 31)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 4:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 30)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 5:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                    }while(dia <= 0 && dia > 31);
                    break;
                case 6:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 30)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 7:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 31)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 8:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 31)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 9:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 30)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 10:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 31)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 11:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 30)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                case 12:
                    do{
                        System.out.print("Insere o dia: ");
                        dia = input.nextInt();
                        if(dia > 31)
                            dia = 0;
                    }while(dia <= 0);
                    break;
                default:
                    break;
            }
        }
        System.out.println("Dia: "+ dia);
        System.out.println("Mes: "+ mes);
        System.out.println("Ano: "+ ano);
    }
    
}
