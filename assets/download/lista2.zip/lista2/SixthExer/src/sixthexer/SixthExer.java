/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sixthexer;

import java.util.Scanner;

/**
 *
 * @author alyson
 */
public class SixthExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Digite o Salario: ");
        double salario = input.nextDouble(), aumento = 0, newSalario;
        System.out.print("Digite a classificação: ");
        String test = input.next();
        if(test.toLowerCase().compareTo("excelente")== 0)
            aumento = (salario*6)/100;
        else if(test.toLowerCase().compareTo("bom")== 0)
            aumento = (salario*4)/100;
        else if(test.toLowerCase().compareTo("mau")== 0)
            aumento = (salario*1.5)/100;
        else
            System.out.println("Classificaçaõ inválida...");
        newSalario = salario + aumento;
        System.out.println("Aumento: "+ aumento);
        System.out.println("New Salario: "+ newSalario);
    }
    
}
