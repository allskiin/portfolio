/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package secondexer;

import java.util.Scanner;

/**
 *
 * @author alyson
 */
public class SecondExer {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int i,v; boolean item;
        i = input.nextInt();
        v = input.nextInt();
        if(i < 10 || v >= 50)
            item = false;
        else
            item = true;     
        //item = !(i<10 || v >= 50);
        System.out.println(item);
    }
    
}
