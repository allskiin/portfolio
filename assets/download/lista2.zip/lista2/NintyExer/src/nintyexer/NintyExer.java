/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package nintyexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class NintyExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner input = new Scanner(System.in);
       System.out.println("Insere o dia: ");
       int day = input.nextInt();
       if(day == 1)
           System.out.println("Saturday");
       else if(day == 2)
           System.out.println("Sunday");
       else if(day == 3)
           System.out.println("Monday");
       else if(day == 4)
           System.out.println("Tuesday");
       else if(day == 5)
           System.out.println("Wednesday");
       else
           System.out.println("Dia invalido...");
    }
    
}
