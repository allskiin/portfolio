/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package firstexer;

/**
 *
 * @author alyson
 */
import java.util.Scanner;
public class FirstExer {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int x,y,z;
        x = input.nextInt();
        y = input.nextInt();
        z = input.nextInt();
            if(x > y && y > z)
                System.out.println("x > y e y > z");
            else if(x < 0 && y < 0)
                System.out.println("x e y menos que 0");
            else if(x != 0 && y != 0)
                System.out.println("x e y maiores que 0");
            else if(x == y && x != z)
                System.out.println("X igual a y e diferente de z");        
    }
    
}
