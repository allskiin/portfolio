/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package seventyexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class SeventyExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double temp;
        temp = input.nextDouble();
        if(temp < 10)
            System.out.println("Muito frio");
        else if(temp >= 10 && temp <= 17)
            System.out.println("frio");
        else if(temp >= 17 && temp <= 23)
            System.out.println("Bom tempo");
        else if(temp >= 23 && temp <= 27)
            System.out.println("Calor");
        else
            System.out.println("Perigo de exposição solar");
    }
    
}
