/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package isptec.pii;

/**
 *
 * @author alyso
 */
public class ex3 {
    public static String conversaoMes(int dia, int mes, int ano){
        String data;
        switch(mes){
            case 1: data = "Janeiro"; break;
            case 2: data = "Fevereiro"; break;
            case 3: data = "Março"; break;
            case 4: data = "Abril"; break;
            case 5: data = "Maio"; break;
            case 6: data = "Junho"; break;
            case 7: data = "Julho"; break;
            case 8: data = "Agosto"; break;
            case 9: data = "Setembro"; break;
            case 10: data = "Outubro"; break;
            case 11: data = "Novembro"; break;
            case 12: data = "Dezembro"; break;
            default:
                data = "erro";
                break;
        }
        return data;
    }
}
