/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package isptec.pii.exercicios;

/**
 *
 * @author alyso
 */
public class ex4 {
    public static boolean capicua(int num){
        int i = 0, test = 0, num1 = num, num2 = num, num3 = num; 
        do{//direita à esquerda
            num1 /= 10; i++;
        }while((num1 % 10) != 0); 
        int direitaE[] = new int [i], esquerdaD[] = new int [i];
        i = 0;
        do{//direita à esquerda
            direitaE[i] = (num1%10);
            num1 /= 10; i++;
        }while((num1 % 10) != 0);
        i = 0;
        do{//esquerda à direita
            esquerdaD[i] = (num3%10);
            num3 /= 10; i++;
        }while((num3 % 10) != 0); 
            for (int j = 0; j < i; j++) {
                if(direitaE[j] == esquerdaD[j])
                    test++;
            }
        return test == (i/2);
    }
}
