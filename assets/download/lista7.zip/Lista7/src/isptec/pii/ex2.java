/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package isptec.pii;

/**
 *
 * @author alyso
 */
public class ex2 {
    public static void cabecalho(String nome){
        System.out.println("#_________________________ CABEÇALHO ___________________________#");
        System.out.println("ISPTEC - INSTITUTO SUPERIOR POLITECNICO DE TECNOLOGIAS E CIENCIAS");
        System.out.println("DISCIPLINA DE PROGRAMACAO II");
        System.out.println("Nome: "+ nome);
        System.out.println("#_______________________________________________________________#");
    }
}
