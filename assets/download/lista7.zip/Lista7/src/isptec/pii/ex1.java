/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package isptec.pii;

/**
 *
 * @author alyso
 */
public class ex1 {
    public static String conversaoNum(int num){
        String extense = null;
            switch(num){
                case 1: extense = "um"; break;
                case 2: extense = "dois"; break;
                case 3: extense = "três"; break;
                case 4: extense = "quatro"; break;
                case 5: extense = "cinco"; break;
                case 6: extense = "seis"; break;
                case 7: extense = "sete"; break;
                case 8: extense = "oito"; break;
                case 9: extense = "nove"; break;
                case 10: extense = "dez"; break;
                default:
                    extense = "erro";
                    break;
            }
        return extense;
    }
}


