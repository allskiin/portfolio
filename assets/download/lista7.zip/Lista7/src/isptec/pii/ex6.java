/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package isptec.pii;

/**
 *
 * @author alyso
 */
public class ex6 {
    public static int somaDiagonalPrincipal(int m [][]){
        return (m[0][0]+m[1][1]+m[2][2]+m[3][3]);
    }
}
