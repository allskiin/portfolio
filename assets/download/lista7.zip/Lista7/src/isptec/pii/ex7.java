/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package isptec.pii;

/**
 *
 * @author alyso
 */
public class ex7 {
    public static void quadradoSolido(char x, int lado){
        System.out.println("#____ QUADRADO SOLIDO ____#");
            for (int i = 0; i < lado; i++) {
                for (int j = 0; j < lado; j++) {
                    System.out.print(x);
                }
                System.out.print("\n");
            }
        System.out.println("#_________________________#");    
    }
}
