/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package isptec.pii;

/**
 *
 * @author alyso
 */
public class ex8 {
    public static void matrizBordas(int m[][], int linha, int coluna){
        System.out.println("#____ BORDAS DA MATRIZ ____#");
            for (int i = 0; i < linha; i++) {
                for (int j = 0; j < coluna; j++) {
                    if(i == 0 || i == (linha-1))
                        System.out.print(m[i][j]+" ");
                    else{
                        if(j == 0 || j == (coluna-1))
                            System.out.print(m[i][j]+" ");
                        else
                            System.out.print("  ");
                    }
                }
                System.out.print("\n");
            }
        System.out.println("#_________________________#");   
    }
}
