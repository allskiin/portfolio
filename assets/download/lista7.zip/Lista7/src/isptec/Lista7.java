
package isptec;
import isptec.pii.ex1;
import isptec.pii.ex2;
import isptec.pii.ex3;
import isptec.pii.ex6;
import isptec.pii.ex7;
import isptec.pii.ex8;
import isptec.pii.exercicios.ex4;
import isptec.pii.exercicios.ex5;
import static java.lang.Character.toLowerCase;
import java.util.Scanner;

/**
 *
 * @author alyson
 */
public class Lista7 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        char op;
        do{
        System.out.println("\n#____ LISTA ____#");
        System.out.println("a) NÚMERO POR EXTENSO");
        System.out.println("b) CABEÇALHO");
        System.out.println("c) DATA <DD/MM/AAAA>");
        System.out.println("d) CAPICUA");
        System.out.println("e) CONSUMO DO APARELHO");
        System.out.println("f) SOMA DIAGONAL PRINCIPAL MATRIZ");
        System.out.println("g) QUADRADO SOLIDO");
        System.out.println("h) BORDAS DA MATRIZ");
        System.out.println("s) SAIR");
        System.out.print("OPÇÃO: ");
        op = in.next().charAt(0);
            switch(toLowerCase(op)){
                case 'a':
                    System.out.print("INSIRA O NÚMERO: ");
                    int num = in.nextInt();
                    String extense = ex1.conversaoNum(num);
                        if(extense.equals("erro"))
                            System.out.println("Erro  na conversão...");
                        else
                            System.out.println("Número "+num+" = "+extense);
                    break;
                case 'b':
                    System.out.print("INSIRA O NOME: ");
                    String nome = in.next();
                    ex2.cabecalho(nome);
                    break;
                case 'c':
                    System.out.print("INSIRA O DIA: ");
                    int dia = in.nextInt();
                    System.out.print("INSIRA O MES: ");
                    int mes = in.nextInt();
                    System.out.print("INSIRA O ANO: ");
                    int ano = in.nextInt();
                    String mesEx = ex3.conversaoMes(dia,mes, ano);
                        if(mesEx.equals("erro"))
                            System.out.println("Erro  na conversão...");
                        else
                            System.out.println(dia +" de "+mesEx+" "+ano);
                    break;
                case 'd':
                    System.out.print("INSIRA O NÚMERO: ");
                    num = in.nextInt();
                    boolean res = ex4.capicua(num);
                        if(res == true)
                            System.out.println("Número: "+num+" é capicua");
                        else
                            System.out.println("Número: "+num+" não é capicua");
                    break;
                case 'e':
                    System.out.print("INSIRA O NOME DO APARELHO: ");
                    nome = in.next();
                    System.out.print("INSIRA AS HORAS QUE ESTARÁ LIGADO O "+nome +": ");
                    int tempo = in.nextInt();
                    System.out.print("INSIRA A POTENCIA DO "+nome +" <WATTS>: ");
                    int potencia = in.nextInt();
                    System.out.println("O "+nome+" IRÁ CONSUMIR "+ex5.ConsumoAparelho(tempo, potencia)+"kw/hora DURANTE O MES");
                    break;
                case 'f':
                    int m[][] = new int[4][4];
                    for (int i = 0; i < 4; i++) {
                        for (int j = 0; j < 4; j++) {
                            System.out.print("INSIRA O NÚMERO DA "+(i+1)+"ª LINHA E "+(j+1)+"ª COLUNA: ");
                            m[i][j] = in.nextInt();
                        }
                    }
                    System.out.println("DIAGONAL PRINCIPAL SOMA: "+ex6.somaDiagonalPrincipal(m));
                    break;
                case 'g':
                    System.out.print("INSIRA O CARACTER: ");
                    char x = in.next().charAt(0);
                    System.out.print("INSIRA O VALOR DOS LADOS: ");
                    int lado = in.nextInt();
                    ex7.quadradoSolido(x, lado);
                    break;
                case 'h':
                    System.out.print("INSIRA O NÚMERO DE LINHAS DA MATRIZ: ");
                    int numL = in.nextInt();
                    System.out.print("INSIRA O NÚMERO DE COLUNAS DA MATRIZ: ");
                    int numC = in.nextInt();
                    int mBorda [][] = new int [numL][numC]; 
                        for (int i = 0; i < numL; i++) {
                            for (int j = 0; j < numC; j++) {
                                System.out.print("INSIRA O NÚMERO DA "+(i+1)+"ª LINHA E "+(j+1)+"ª COLUNA: ");
                                mBorda[i][j] = in.nextInt();
                            }
                        }
                    ex8.matrizBordas(mBorda, numL, numC);
                    break;
                
            }
        }while(toLowerCase(op) != 's');
    }
    
}
