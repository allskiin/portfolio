/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package firstexer;

import java.util.Scanner;



/**
 *
 * @author alyso
 */
public class FirstExer {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num=0, soma=0, i = 0; double media=0;
            while(num != 99){
                System.out.print("Digite o número: ");
                num = input.nextInt();
                    if(num != 99){
                        soma +=num;
                        i++;
                    }
            }
            if(num == 99 && i != 0)
                media = soma/i;
            System.out.println("Media: "+ media);
    }
    
}
