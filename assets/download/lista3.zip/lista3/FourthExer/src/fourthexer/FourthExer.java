/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package fourthexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class FourthExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Digite a massa: ");
        double massaInicial = input.nextInt();
        double massaFinal = massaInicial;
        int temp = 0;
        while(massaFinal >= 0.8){
            massaFinal /= 2;
            temp += 110;
        }
        System.out.println("Massa Inicial: " + massaInicial + "\nMassa Final: "+ massaFinal + "\nTempo necessário: "+ temp);
    }
    
}
