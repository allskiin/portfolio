/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package fifthexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class FifthExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Digite o número: ");
        int n = input.nextInt();
        int i=1, j=3;
        if(n >= 1){
            System.out.print("S = 1 ");
            while(n > 1){
                System.out.print(" + "+i+"/"+j);
                i++;
                j+=2;
                n--;
            }
            System.out.print("\n");
        }    
    }   
}
