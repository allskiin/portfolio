/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ninthexer;

import java.util.Scanner;
import java.lang.Math;

/**
 *
 * @author alyso
 */
public class NinthExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int N = -1, i = 2, j = 1, fat; double cos = 1;
        System.out.print("Digite o valor de x: "); int x = input.nextInt();
        while(N % 2 != 0 || N < 1){
            System.out.print("Digite o valor de N: "); N = input.nextInt();
        }
        while(i <= N){
            fat =fatorial(i);
            if(j % 2 == 0)
                cos += ((Math.pow(x, i))/fat);
            else
                cos -= ((Math.pow(x, i))/fat);
            i+=2;
            j++;   
        }
        System.out.println("Cos = "+cos);
    }
    public static int fatorial(int x){
        int fat;
        for(fat = 1; x > 1; x -=1)
            fat = fat * x;
        return fat;
    } 
}
