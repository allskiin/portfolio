/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eighthexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class EighthExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Digite o número: "); int num = input.nextInt();
        int i = 1, impares = 0;
        System.out.print("Impares: ");
        while(i < num){
            if(i % 2 != 0){
                impares += i;
                System.out.print(i+" + ");
            }
            if(impares == num)
                i = num;
            else if(impares > num)
                i = num;
            i++;
        }
        if(impares == num)
            System.out.println("O número "+num +" é um quadrado perfeito");
        else
            System.out.println("O número "+num +" não é um quadrado perfeito");
    }
}
