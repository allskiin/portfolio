/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tenthexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class TenthExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Digite o número: "); int num = input.nextInt();
        int x=1, y = 1, z=num, i = 1, j = 1;
        while(y <= num){
            while(x <= z){
                System.out.print("* "); x++;
            }
            System.out.print("\n");
            while(i <= j && j <=num){
                System.out.print("• "); i++;
            }
            i=1; j++; y++; z--; x = 1;
        }
        System.out.print("\n");
    }
}
