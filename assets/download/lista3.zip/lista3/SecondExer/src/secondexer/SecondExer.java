/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package secondexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class SecondExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num, maior=0, i;
            for(i=0; i<10; i++){
                System.out.print("Digite o número: ");
                num = input.nextInt();
                    if(num > maior)
                        maior = num;    
            }
            System.out.println("O maior é: "+ maior);
    }
    
}
