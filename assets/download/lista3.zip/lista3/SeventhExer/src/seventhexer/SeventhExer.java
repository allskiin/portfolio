/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package seventhexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class SeventhExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Digite o 1º número: "); int n1 = input.nextInt();
        System.out.print("Digite o 2º número: "); int n2 = input.nextInt();
        int i=1, div1 = 0, div2 = 0;
        while(i < n1){
            if(n1 % i == 0)
                div1 += i;
            i++;
        }i = 1;
        while(i < n2){
            if(n2 % i == 0)
                div2 += i;
            i++;
        }
        if(div1 == n2 && div2 == n1){
            System.out.println("Os múmeros "+n1 +" e "+n2 +" são amigos");
            System.out.println("Soma dos divires de "+n1 +" = "+div1);
            System.out.println("Soma dos divires de "+n2 +" = "+div2);
        }else{
            System.out.println("Os múmeros "+ n1 +" e "+n2 +" não são amigos");
            System.out.println("Soma dos divires de "+n1 +" = "+ div1);
            System.out.println("Soma dos divires de "+n2 +" = "+ div2);
        }
    }
    
}
