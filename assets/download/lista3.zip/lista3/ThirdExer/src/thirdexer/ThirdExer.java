/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package thirdexer;

import java.util.Scanner;

/**
 *
 * @author alyso
 */
public class ThirdExer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Digite o número: ");
        int num = input.nextInt();
        int fatorial = fatorial(num);
        System.out.println("Fatorial de "+ num +" é = "+ fatorial);
    }
    public static int fatorial(int x){
        int fat;
        for(fat = 1; x > 1; x -=1)
            fat = fat * x;
        return fat;
    } 
}
